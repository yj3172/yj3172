package mybatmodel;

public class commentdto {
	String boardnum;
	String commentwrither;
	String comment;
	String day;
	String commentnum;
	public String getCommentnum() {
		return commentnum;
	}
	public void setCommentnum(String commentnum) {
		this.commentnum = commentnum;
	}
	public String getBoardnum() {
		return boardnum;
	}
	public void setBoardnum(String boardnum) {
		this.boardnum = boardnum;
	}
	public String getCommentwrither() {
		return commentwrither;
	}
	public void setCommentwrither(String commentwrither) {
		this.commentwrither = commentwrither;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getDay() {
		return day;
	}
	public void setDay(String day) {
		this.day = day;
	}
	

}
