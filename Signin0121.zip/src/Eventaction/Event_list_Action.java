package Eventaction;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Dto.ActionForward;
import Dto.Event_list_dto;
import Eventsvc.Event_list_service;


public class Event_list_Action implements action{
@Override
public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
	// TODO Auto-generated method stub
		ActionForward forward = new ActionForward();
		
		
		Event_list_service list = new Event_list_service();
		ArrayList<Event_list_dto> articlelist = new ArrayList<Event_list_dto>();
		
		articlelist = list.getArticleList();
		
		request.setAttribute("articleList", articlelist);
	
		System.out.println(articlelist.size());
		forward.setRedirect(false);
		forward.setPath("E_event.jsp");
	return forward;
}
}
