package com.fruit.peach.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fruit.peach.repository.BorderDAO;
import com.fruit.peach.service.BorderService;
import com.fruit.peach.vo.BorderDTO;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

@Controller // ���Ǿ�.(�̰� ~�� , ��� �˷��ֱ�)
public class BorderController {

	@Autowired
	private BorderDAO singletoneDAO; //Service�� ����ϸ� �����ϰ� �ȴ�
	
	@Autowired
	private BorderService singletoneService;
	
	@ResponseBody
	@RequestMapping("/index")
	public JSONArray index(Model model, HttpServletResponse response,HttpServletRequest request) throws IOException { //model : object�� ������ ���� �������Ű����� (������������)
		/*List<BorderDTO> list = singletoneDAO.getList();*/ //service�� ��������ν� �����ϰ� �Ʒ��ٷ� ����
		List<BorderDTO> list = singletoneService.getList();
		System.out.println("들어옴?");
		model.addAttribute("list",list);
		int i=0;
		JSONArray jarray = new JSONArray();
		while(i<list.size()){
			JSONObject jsonObj1 = new JSONObject();
			jsonObj1.put("name", list.get(i).getName());
			jsonObj1.put("pwd", list.get(i).getPwd());
			jsonObj1.put("content", list.get(i).getContent());
			jarray.add(jsonObj1);
			i++;
		}
		response.setHeader("Access-Control-Allow-Origin", request.getHeader("Origin"));
		response.setHeader("Access-Control-Allow-Credentials", "true");
		response.setHeader("Access-Control-Allow-Methods", "POST, GET, OPTIONS, DELETE");
		response.setHeader("Access-Control-Max-Age", "3600");
		response.setHeader("Access-Control-Allow-Headers", "Content-Type, Accept, X-Requested-With, remember-me");
		response.setHeader("Content-Type", "application/json");
		response.setHeader("Accept", "application/json");
		response.getWriter().print(jarray);
		
		return jarray;
	}
	
	@RequestMapping(value="/insert", method=RequestMethod.POST)
	public String insertadd(@ModelAttribute BorderDTO vo) {
		singletoneDAO.insert(vo);
		return "redirect:/index";
	}
	
	@RequestMapping("/deleteform") //�ʿ�������κ�...
	public String deletebutton() {
		return "/WEB-INF/views/DeleteForm.jsp";
	}
	
	@RequestMapping(value="/deleteval", method= {RequestMethod.POST,RequestMethod.GET})
	public String delete(@RequestParam Integer no) { //RequestParam : (�Ѱ�������)
		//��й�ȣ�� �´�? (���ǹ�) ���⿡������
		singletoneDAO.delete(no);
		return "redirect:/index";
	}
}
