package com.fruit.peach.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fruit.peach.repository.BorderDAO;
import com.fruit.peach.vo.BorderDTO;

@Service
public class BorderService { //���ǹ��� �������� ����
	@Autowired
	private BorderDAO singleDAO;
	
	public List<BorderDTO> getList() {
		return singleDAO.getList();
	}
}
