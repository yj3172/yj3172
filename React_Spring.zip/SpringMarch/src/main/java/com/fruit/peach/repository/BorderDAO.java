package com.fruit.peach.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.fruit.peach.vo.BorderDTO;

@Repository
public class BorderDAO {

	@Autowired
	private DataSource datasource;
	/*private Connection getConnection() throws SQLException {
	Connection conn = null;
	try {
		Class.forName("com.mysql.jdbc.Driver");
		String url = "jdbc:mysql://localhost/spring";
		conn = DriverManager.getConnection(url, "root", "0000");
	} catch (ClassNotFoundException e) {
		System.out.println(" ����̹� �ε� ���� ");
	}
	return conn;
	}*/
	
	/*public List<BorderDTO> getList() {
		List<BorderDTO> list = new ArrayList<BorderDTO>();
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			//conn = getConnection();
			conn = datasource.getConnection();
			String sql = "SELECT no, name, pwd, content, reg_date" + " FROM spring_tb" + " ORDER BY no desc";
			
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while (rs.next()) {
				BorderDTO vo = new BorderDTO();
				vo.setNo(rs.getInt(1));
				vo.setName(rs.getString(2));
				vo.setPwd(rs.getString(3));
				vo.setContent(rs.getString(4));
				vo.setReg_date(rs.getDate(5));
				list.add(vo);
			}
		} catch (SQLException e) {
		}
		return list;
	}*/
	/*public boolean insert(BorderDTO vo) {
		boolean result = false;
		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			//conn = getConnection();
			conn = datasource.getConnection();
			String sql = "INSERT INTO spring_tb VALUES (1, ?, ?, ?, (SELECT SYSDATE()) )";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getName());
			pstmt.setString(2, vo.getPwd());
			pstmt.setString(3, vo.getContent());
			int count = pstmt.executeUpdate();

			result = (count == 1);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
	}*/
	/*public boolean delete(int no) {
		boolean result = false;
		Connection conn = null;
		PreparedStatement pstmt = null;

		try {
			//conn = getConnection();
			conn = datasource.getConnection();
			String sql = "DELETE FROM spring_tb WHERE no=?";
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, no); // prepareStatement =?����� =1���ͽ���
			int count = pstmt.executeUpdate();

			result = (count == 1);
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return result;
	}*/
	
	//mybatis
	@Autowired
	private SqlSession sqlsession; //configuration�� ����
	
	public List<BorderDTO> getList() {
		List<BorderDTO> list = sqlsession.selectList("guestbook.getList");
		return list;
	}
	
	public void insert(BorderDTO vo) {
		sqlsession.insert("guestbook.insert",vo);
	}

	public void delete(int no) {
		sqlsession.delete("guestbook.delete",no);
	}
}
