import React, { Component } from 'react';
class Three extends Component {
    render(){
        return(
           <div>3번이다</div>
        );
    }
}
export default Three;