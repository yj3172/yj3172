import React, { Component } from 'react';
class Read extends Component {
    render(){
        return(
           <article>
           <div>Read</div>
           <form>
               </form>
           </article>
        );
    }
}
export default Read;