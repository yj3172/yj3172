import React, { Component } from 'react';
class Two extends Component {
    render(){
        return(
           <div>2번이다</div>
        );
    }
}
export default Two;