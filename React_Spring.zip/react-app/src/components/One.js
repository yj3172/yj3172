import React, { Component } from 'react';
class One extends Component {
    render(){
        return(
           <div>1번이다</div>
        );
    }
}
export default One;