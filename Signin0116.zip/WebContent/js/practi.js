$(window).load(function() {
  $('.flexslider').flexslider({
    animation: "slide"
  });
});