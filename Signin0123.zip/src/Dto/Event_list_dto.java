package Dto;

public class Event_list_dto {
		String title;
		String eventstart;
		String eventfinal;
		int eventnum;
		public int getEventnum() {
			return eventnum;
		}
		public void setEventnum(int eventnum) {
			this.eventnum = eventnum;
		}
		public String getTitle() {
			return title;
		}
		public void setTitle(String title) {
			this.title = title;
		}
		public String getEventstart() {
			return eventstart;
		}
		public void setEventstart(String eventstart) {
			this.eventstart = eventstart;
		}
		public String getEventfinal() {
			return eventfinal;
		}
		public void setEventfinal(String eventfinal) {
			this.eventfinal = eventfinal;
		}
		
}
